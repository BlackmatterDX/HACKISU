package package1;

public class game {

    public static final int LIBRARY = 2;
    public static final int CURTISS = 0;
    public static final int MU = 1;

    public static void main(String[] args) {
   	 // TODO Auto-generated method stub

   	 Tracking items = new Tracking();
   	 int indexNum = 0;
   	 int buildingNum = CURTISS;

   	 System.out.println("This is your final year at Iowa State University and your paper for The Dynamics "
   	 		+ "and analysis of BioPhysics combined with Animal Husbandry"
   	 		+ " in a space type setting is due tonight at midnight. \n"
   			 + "The time is 11:50pm and you need to goto your professor's office to turn\nin your final assignment to him before the deadline. "
   			 + "Otherwise, you fail your course and have to await the wrath of mom and dad.\n");
   	 Audio allen = new Audio("GameIntro.wav");
   	 
   	 Rooms[] Mu = new Rooms[5];
   	 Mu[0] = new Rooms(1, "MemorialUnion");
   	 Mu[1] = new Rooms(2, "MemorialUnion");
   	 Mu[2] = new Rooms(3, "MemorialUnion");
   	 Mu[3] = new Rooms(4, "MemorialUnion");
   	 Mu[4] = new Rooms(5, "MemorialUnion");

   	 Rooms[] Library = new Rooms[5];
   	 Library[0] = new Rooms(0, "Library");
   	 Library[1] = new Rooms(1, "Library");
   	 Library[2] = new Rooms(2, "Library");
   	 Library[3] = new Rooms(3, "Library");
   	 Library[4] = new Rooms(4, "Library");

   	 Rooms[] Curtiss = new Rooms[5];

   	 Curtiss[0] = new Rooms(1, "CurtisHall");
   	 Curtiss[1] = new Rooms(2, "CurtisHall");
   	 Curtiss[2] = new Rooms(3, "CurtisHall");
   	 Curtiss[3] = new Rooms(4, "CurtisHall");
   	 Curtiss[4] = new Rooms(5, "CurtisHall");
   	 
   	 while (true) {
   		 if (buildingNum == CURTISS) {
   			 indexNum = Curtiss[indexNum].room(items);
   			 if(indexNum == -1)
   			 {
   				 indexNum = 0;
   				 buildingNum = MU;
   			 }
   			 else if(indexNum==-100)
   			 {
   				 break;
   			 }
   		 } else if (buildingNum == MU) {
   			 indexNum = Mu[indexNum].room(items);
   			 if(indexNum == -1)
   			 {
   				 indexNum = 0;
   				 buildingNum = LIBRARY;
   			 }
   		 } else if (buildingNum == LIBRARY) {
   			 indexNum = Library[indexNum].room(items);
   			 if(indexNum == -1)
   			 {
   				 indexNum = 0;
   				 buildingNum = CURTISS;
   			 }
   		 }
   	 }
    }

}


