package package1;
public class Tracking{
    private int key;
    private boolean LGO; //whether the library gate is unlocked
    private boolean professorPresent;
    
    public Tracking()
    {
   	 key = 0;
   	 LGO = false;
   	 professorPresent = false;
    }
    
    public boolean isProfessorPresent(){
   	 return professorPresent;
    }
    public void changeProfessorPresent(){
   	 professorPresent = true;
    }
    public void increaseKey()
    {
   	 key++;
    }
    public int getKeyAmount()
    {
   	 return key;
    }
    public void useKey()
    {
   	 key--;
    }
    
    public void unlockLibraryGate()
    {
   	 LGO = true;
    }
    
    public boolean isLibraryUnlocked()
    {
   	 return LGO;
    }
}


