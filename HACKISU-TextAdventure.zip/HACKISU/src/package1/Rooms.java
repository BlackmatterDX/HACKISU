package package1;

import java.util.*;

public class Rooms {
    private int roomNumber;
    private String building;
    private Scanner scan;
    public Rooms(int rNum, String b) {
   	 roomNumber = rNum;
   	 building = b;
   	 scan = new Scanner(System.in);

    }

    // chooses room method to call
    public int room(Tracking i) {
   	 if (building.equals("MemorialUnion")) {
   		 if (roomNumber == 1) {
   			 return MemorialUnion1(i);
   		 } else if (roomNumber == 2) {
   			 return MemorialUnion2(i);
   		 } else if (roomNumber == 3) {
   			 return MemorialUnion3(i);
   		 } else if (roomNumber == 4) {
   			 return MemorialUnion4(i);
   		 } else if (roomNumber == 5) {
   			 return MemorialUnion5(i);
   		 } else {
   			 System.out.println("That room number doesn't exist");
   		 }

   	 } else if (building.equals("CurtisHall")) {
   		 if (roomNumber == 1) {
   			 return CurtisHall1(i);
   		 } else if (roomNumber == 2) {
   			 return CurtisHall2(i);
   		 } else if (roomNumber == 3) {
   			 return CurtisHall3(i);
   		 } else if (roomNumber == 4) {
   			 return CurtisHall4(i);
   		 }
   	 }

   	 {
   		 if (building.equals("Library")) {
   			 if (roomNumber == 0) {
   				 return LibraryRoom0(i);
   			 } else if (roomNumber == 1) {
   				 return LibraryRoom1(i);
   			 } else if (roomNumber == 2) {
   				 return LibraryRoom2(i);
   			 } else if (roomNumber == 3) {
   				 return LibraryRoom3(i);
   			 } else if (roomNumber == 4) {
   				 return LibraryRoom4(i);
   			 } else {
   				 System.out.println("Room number doesn't exist.");
   			 }
   		 }
   		 return -99;
   	 }
    }

    public int LibraryRoom0(Tracking i) {
   	 
   	 System.out.println("\nYou have entered the first room of the library.");
   	 while (true) {
   		 System.out.print("\nWhat do you want to do?(search, examine)\n> ");
   		 String command = scan.next().toLowerCase();

   		 if (command.equals("search")) {
   			 System.out.println("\nYou see a room with a cluster of computers to your left. You also "
   					 + "\nsee a doorway infront and a stairway to the left. The entance is behind you.");
   		 } else if (command.equals("examine")) {
   			 System.out.print("\nWhat do you want to examine?(computers, doorway, stairway)\n> ");
   			 command = scan.next().toLowerCase();

   			 if (command.equals("computers") || command.equals("computer")) {
   				 System.out.println("\nOne of the computers is logged onto with a note that says,\"2341\" ");
   			 } else if (command.equals("doorway")) {
   				 System.out.print("\nYou see an unlocked wooden door.\n Do you wish to enter?(yes or no)\n> ");
   				 command = scan.next().toLowerCase();

   				 if (command.equals("yes") || command.equals("y")) {
   					 // leaves to go to library room 1

   					 return 1;
   				 }
   			 } else if (command.equals("stairway")) {
   				 if (i.isLibraryUnlocked()) {
   					 System.out.println("You go up the stairs");

   					 return 2;
   				 }
   				 System.out.print(
   						 "\nThere is a gate blocking the stairway with a keyhold. What will you do?(leave, use)");
   				 command = scan.next().toLowerCase();

   				 if (command.equals("use")) {
   					 System.out.print("\nWhat will you use?\n> ");
   					 command = scan.next().toLowerCase();

   					 if (command.equals("key") && i.getKeyAmount() >= 1) {
   						 i.useKey();
   						 i.unlockLibraryGate();
   						 System.out.println("You unlocked the gate and go up to the second floor.");

   						 return 2;
   					 }
   				 }
   			 } else {
   				 System.out.println("\nYou can't examine that.");
   			 }
   		 } else {
   			 System.out.println("\nI can't understand what you said");
   		 }
   	 }

    }

    public int LibraryRoom1(Tracking i) {
   	 
   	 System.out.println("\nYou have entered the second room on the first floor.");
   	 while (true) {
   		 System.out.print("\nWhat do you want to do?(search, examine, leave)\n> ");
   		 String command = scan.next().toLowerCase();

   		 if (command.equals("search")) {
   			 System.out.println(
   					 "\nYou see a closed off room with computers and tables. There is only the exit behind you.");
   		 } else if (command.equals("examine")) {
   			 System.out.print("\nWhat do you want to examine?(computers, tables) \n> ");
   			 command = scan.next().toLowerCase();

   			 if (command.equals("computers")) {
   				 System.out.println("\nYou see a 3-D maze being traveled though.");
   			 } else if (command.equals("tables")) {
   				 System.out.println("\nYou see a key on the table and you pick it up.");
   				 i.increaseKey();
   			 } else {
   				 System.out.println("\nYou can't examine that.");
   			 }
   		 } else if (command.equals("leave")) {
   			 System.out.println("\nYou leave the room back the way you came.");

   			 return 0;
   		 } else {
   			 System.out.println("\nI can't understand what you said");
   		 }
   	 }
    }

    public int LibraryRoom2(Tracking i) {
   	 
   	 System.out.println("\nYou have entered the second floor.");
   	 while (true) {
   		 System.out.print("\nWhat do you want to do?(search, examine, leave, goup)\n> ");
   		 String command = scan.next().toLowerCase();

   		 if (command.equals("search")) {
   			 System.out.println(
   					 "\nYou see a few empty tables and a person standing in a corner. The stairs also keep going up.");
   		 } else if (command.equals("examine")) {
   			 System.out.print("\nWhat do you want to examine?(tables, person)\n> ");
   			 command = scan.next().toLowerCase();
   			 if (command.equals("tables")) {
   				 System.out.println("\nThe tables have a bunch of papers scattered over them. "
   						 + "\nBut it seems like the indivual contents is meaningless");
   			 } else if (command.equals("person")) {
   				 System.out.println("\nThe man is just looking into a corner mumbling \"It's all in the numbers\"");
   			 } else {
   				 System.out.println("\nYou can't examine that.");
   			 }
   		 } else if (command.equals("leave")) {
   			 System.out.println("\nYou go back down stairs");

   			 return 0;
   		 } else if (command.equals("goup")) {
   			 System.out.println("\nYou go up the stairs to the next floor.");

   			 return 3;
   		 } else {
   			 System.out.println("\nI can't understand what you said");
   		 }
   	 }
    }

    public int LibraryRoom3(Tracking i) {
   	 
   	 System.out.println("\nYou have entered the first room on the third floor");
   	 while (true) {
   		 System.out.print("\nWhat do you want to do?(search, examine, leave)\n> ");
   		 String command = scan.next().toLowerCase();

   		 if (command.equals("search")) {
   			 System.out.println("\nYou see a room with tons of tables with the occasional person studying. "
   					 + "You see a door to the right of you.");
   		 } else if (command.equals("examine")) {
   			 System.out.print("\nWhat do you want to examine?(tables, door)\n> ");
   			 command = scan.next().toLowerCase();

   			 if (command.equals("tables")) {
   				 System.out.println(
   						 "\nThe tables seem to be made out of strong wood. Other than that there is nothing else to note.");

   			 } else if (command.equals("door")) {
   				 System.out.print("\nYou see a strong unlocked wooden door.\n Do you wish to enter?(yes or no)\n> ");
   				 command = scan.next().toLowerCase();

   				 if (command.equals("yes") || command.equals("y")) {
   					 // leaves to go to library room 4

   					 return 4;
   				 }
   			 } else {
   				 System.out.println("\nYou can't examine that.");
   			 }
   		 } else if (command.equals("leave")) {
   			 System.out.println("\nYou go back down stairs to the second floor.");

   			 return 2;
   		 } else {
   			 System.out.println("\nI can't understand what you said");
   		 }
   	 }
    }

    public int LibraryRoom4(Tracking i) {
   	 
   	 System.out.println("\nYou have entered the second room of the third floor.");
   	 while (true) {
   		 System.out.print("\nWhat do you want to do?(search, examine, leave)\n> ");
   		 String command = scan.next().toLowerCase();

   		 if (command.equals("search")) {
   			 System.out.println("\nYou see a smaller room with some tables and a computer dimmly glowing.");
   		 } else if (command.equals("examine")) {
   			 System.out.print("\nWhat do you want to examine?(tables, computer)\n> ");
   			 command = scan.next().toLowerCase();

   			 if (command.equals("tables")) {
   				 System.out.println("\nYou see some paper that seems very familar to you.");
   			 } else if (command.equals("computer")) {
   				 while (true) {
   					 System.out
   							 .print("\nYou see the that your professor was on this computer but he is not here anymore. "
   									 + "\nBefore you are about to leave a small text box opens up saying "
   									 + "\n\"Please input the code\"(leave or enter code) \n> ");
   					 command = scan.next().toLowerCase();

   					 if (command.equals("2341")) {
   						 System.out.println(
   								 "\nIt dawns apon you that the code it wants is the one you found on the first floor. "
   										 + "\nAfter realizing this you enter it in and there is a not saying that we "
   										 + "\nis going to be back at his office. "
   										 + "You sign as you read this and head back to Curtiss.");

   						 i.changeProfessorPresent();
   						 return -1;
   					 } else if (command.equals("leave")) {
   						 System.out.println("\nYou leave the computers keyboard.");
   					 } else {
   						 System.out.println("\nThat is not the code.");
   					 }
   				 }
   			 }
   		 } else if (command.equals("leave")) {
   			 System.out.println("\nYou go back to the other room.");

   			 return 3;
   		 } else {
   			 System.out.println("\nI can't understand what you are saying.");
   		 }
   	 }
    }

    public int CurtisHall1(Tracking i) // big open area. Can go straight or
   									 // right.
    {
   	
   	 System.out.println("You have entered Curtis Hall. There is a large opening with a railing in front of you.\n "
   			 + "Three hallways all heading off in different directions. One to the left, one straight, and one to the right. \n"
   			 + "The hall to the left is blocked off by CIA agents, all of whom are carrying delicious soylent� drinks SPONSORED BY soylent�.");
   	 Audio jeff1 = new Audio("CurtissIntro.wav");
   	 
   	 while (true) {
   		 System.out.println("What do you want to do?:(search,examine,enter)");
   		 Audio jeff2 = new Audio("WhatDoYouWantToDo");
   		
   		 String s = scan.next().toLowerCase();
   		 if (s.equals("search")) {
   			 System.out.println("You look around the railing but fail to find anything noteworthy");
   			 Audio jeff3 = new Audio("YouLookAroundTheRailing.wav");
   		 } else if (s.equals("examine")) {
   			 System.out.println("You question whether or not you wish to examine the CIA agents."
   			 		+ " Then you remember you value your life.");
   			 Audio jeff4 = new Audio("YouQuestionWhetherOrNotToExamine.wav");
   		 } else if (s.equals("enter")) {
   			 System.out.println("What do you enter?:(fronthallway,righthallway)");
   			 Audio jeff5 = new Audio("WhatDoYouEnter.wav");
   			 String m = scan.next().toLowerCase();
   			 if (m.equals("fronthallway")) {
   				 return 1;
   			 } else if (m.equals("righthallway")) {
   				 return 2;
   			 } else {
   				 System.out.println("You cannot enter here");
   				 Audio jeff6 = new Audio("YouCannotEnterHere.wav");
   			 }
   		 }

   	 }
    }

    public int CurtisHall2(Tracking i) // Big lecture hall
    {
   	 
   	 String s;
   	 System.out.println("You go straight, walk through a set of double doors \n"
   	 		+ "and enter a large lecture hall. ");
   	 Audio jeff1 = new Audio("YouGoStraightWalkThrough.wav");
   	 while (true) {
   		 System.out.println("What do you want to do?:(search,examine,exit)");
   		 Audio jeff2 = new Audio("WhatDoYouWantToDo.wav");
   		 s = scan.next().toLowerCase();
   		 if (s.equals("search")) {
   			 System.out.println("You find a half eaten snickers bar on the ground. Possibly from the professor");
   			 Audio jeff3 = new Audio("YouFindAHalfEaten.wav");
   		 } else if (s.equals("examine")) {
   			 System.out.println("You question eating the snickers bar but remember you have morals.");
   			 Audio jeff4 = new Audio("YouQuestionEatingTheSnickersBar.wav");
   		 } else if (s.equals("exit")) {
   			 return 0;
   		 }

   	 }
    }

    public int CurtisHall3(Tracking i) // stand outside entrance to office
    {
   	 
   	 String s;
   	 System.out.println("You walk down the Hallway and approach your professor's office door.");
   	 Audio ben1 = new Audio("YouWalkDownTheHallway.wav");
   	 while (true) {
   		 System.out.println("What do you want to do?(open) ");
   		 Audio ben2 = new Audio("WhatDoYouWantToDo.wav");
   		 s = scan.next().toLowerCase();
   		 if (s.equals("open")) {

   			 return 3;
   		 } else {
   			 System.out.println("ERROR ERROR ERROR");
   			 Audio ben3 = new Audio("ErrorErrorError.wav");
   		 }
   	 }
    }

    public int CurtisHall4(Tracking i) // Office of Professor
    {
   	 
   	 if (!i.isProfessorPresent()) {
   		 System.out.println("You enter your professor's office. To your astonishment he's not here!");
   		 Audio ben4 = new Audio("YouEnterYourProfessor'sOffice.wav");
   		 while (true) {
   			 System.out.println("What do you want to do?:(search,examine,exit)");
   			 Audio ben5 = new Audio("WhatDoYouWantToDo.wav");
   			 String s = scan.next().toLowerCase();
   			 if (s.equals("search")) {
   				 System.out.println(
   						 "You search the room. His office contains a desk with a bunch of scattered papers on it, a typewriter, and a\n "
   						 + "closet in the corner");
   				 Audio ben6 = new Audio("YouSearchTheRoomHisOfficeContains.wav");
   			 } else if (s.equals("examine")) {
   				 System.out.println("What do you examine?:(papers,typewriter,closet)");
   				 String y = scan.next().toLowerCase();
   				 if (y.equals("papers")) {
   					 System.out.println("You discover that the professor has "
   					 		+ "head over to the MU for a bite to eat");
   					 Audio ben7 = new Audio("YouDiscoverThatTheProfessorHasHead.wav");
   					 return -1;
   				 }
   				 else if (y.equals("typewriter"))
   				 {
   					 System.out.println("You stare at this strange contraption"
   					 		+ " but due to generational differences you fail to figure "
   					 		+ "out the\n "
   					 		+ "identity of this alien like object");
   					 Audio ben8 = new Audio("YouStareAtThisStrange.wav");
   				 }
   				 else if (y.equals("closet"))
   				 {
   					 System.out.println("You open the closet only to have  "
   					 		+ "hundreds of bottles of your favorite brand "
   					 		+ ", soylent�, fall out. \n"
   					 		+ "The professor sure has a good taste in drinks.");
   					 Audio ben9 = new Audio("YouOpenTheCloset.wav");
   				 }
   				 else {
   					 System.out.println("You can't examine that");
   				 }
   			 } else if (s.equals("exit")) {

   				 return 2;
   			 } else {
   				 System.out.print("Try again moron");
   				 Audio ben10 = new Audio("TryAgainMoron.wav");
   			 }
   		 }
   	 }

   	 else if (i.isProfessorPresent()) {
   		 System.out.println(
   				 "You enter your professor's office. Lo and behold he's back!"
   				 + " \"Well hello there young one, sorry for my dissaperance\"");
   		 System.out.println("You hand him your homework. Congratulations, YOU WON!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
   		 Audio yess = new Audio("Finale.wav");
   		 return -100;
   	 }
   	 return -9;

    }

    public int MemorialUnion1(Tracking i) // Great star hall
    {
   	 
   	 System.out.println("You have entered Gold Star Hall");
   	 Audio moo1 = new Audio("YouHaveEnteredGoldStarHall.wav");
   	 while (true) {
   		 System.out.println("What do you want to do?:(search, ,enter )");
   		 Audio moo2 = new Audio("WhatDoYouWantToDo.wav");
   		 String s = scan.next().toLowerCase();

   		 if (s.equals("search")) {
   			 System.out.println("You find nothing but some crumbs in a corner. Your lips are dry."
   			 		+ " You really wish you had some refreshing soylent�");
   			 Audio moo3 = new Audio("YouReallyWishYouHadSomeRefreshingSoylent.wav");
   		 }
   		 else if (s.equals("enter")) {
   			 System.out.println("What do you enter?:(endofhallway)");
   			 Audio moo4 = new Audio("WhatDoYouEnter.wav");
   			 String m = scan.next().toLowerCase();
   			 if (m.equals("endofhallway")) {
   				 return 1;
   			 }
   			 else
   			 {
   				 System.out.println("You cannot enter here.");
   				 Audio moo5 = new Audio("YouCannotEnterHere.wav");
   			 }
   		 }
   		 else
   		 {
   			 System.out.println("Error");
   			 Audio moo6 = new Audio("ErrorErrorError.wav");
   		 }

   	 }
    }

    public int MemorialUnion2(Tracking i) // Downstairs main hallway
    {
   	 
   	 System.out.println(
   			 "You go down the stairs and enter a long white hallway. On your left"
   			 + " is the food marketplace,"
   			 + " your right is the foodcourt, and down the hall is the bookstore.");
   	 Audio moo8 = new Audio("YouGoDownTheStairs.wav");
   	 while (true) {
   		 System.out.println("What Do you want to do?:(search, examine,enter)");
   		 
   		 Audio moo9 = new Audio("WhatDoYouWantToDo.wav");
   		 String s = scan.next().toLowerCase();

   		 if (s.equals("Search")) {
   			 System.out.println("There is nothing of interest in the hallway");
   			 Audio moo10 = new Audio("ThereIsNothingOfInterestInTheHallway.wav");
   		 } else if (s.equals("examine")) {
   			 System.out.println("Nothing to examine in the hallway");
   		 } else if (s.equals("enter")) {
   			 System.out.println("What do you enter?(foodmarketplace, foodcourt, bookstore)");
   			 Audio moo11 = new Audio("WhatDoYouEnter.wav");
   			 s = scan.next().toLowerCase();
   			 if (s.equals("foodmarketplace")) {
   				 
   				 return 2;
   			 }

   			 if (s.equals("foodcourt")) {
   				 
   				 return 3;
   			 }

   			 if (s.equals("bookstore")) {
   				 
   				 return 4;
   			 }
   			 

   		 }
   	 }
    }

    public int MemorialUnion3(Tracking i)// food marketplace
    {
   	 

   	 System.out.println(
   			 "You enter the marketplace. Every restaurant you see has overpriced "
   			 + "food marketed at economically unwise college students.");
   	 Audio moo13 = new Audio("YouEnterTheMarketplace.wav");
   	 while (true) {
   		 System.out.println("What Do you want to do?:(search, examine,exit )");
   		 Audio moo14 = new Audio("WhatDoYouWantToDo.wav");
   		 String s = scan.next().toLowerCase();

   		 if (s.equals("search")) {
   			 System.out.println("nothing to search for in here");//replace
   		 } else if (s.equals("examine")) {
   			 System.out.println("You really don't want to examine the food");
   			 Audio moo15 = new Audio("YouReallyDon'tWantToExamineTheFood.wav");
   		 } else if (s.equals("exit")) {

   			 return 1;
   		 }
   	 }
    }

    public int MemorialUnion4(Tracking i)// foodcourt this is where the laptop
   										 // is that
    // tells you where the professor went
    {
   	 
   	 System.out.println(
   			 "You enter the foodcourt. Hundreds of tables and chairs as far as"
   			 + " the eye can see. "
   			 + "You spot one lone laptop on a table in the middle of"
   			 + " the room with some papers around it.");
   	 Audio coww1 = new Audio("YouEnterTheFoodCourt.wav");
   	 while (true) {
   		 System.out.println("What Do you want to do?:(search, examine,exit )");
   		 Audio coww2 = new Audio("WhatDoYouWantToDo.wav");
   		 String s = scan.next().toLowerCase();

   		 if (s.equals("search")) {
   			 System.out.println("Nothing of interest to search for");
   		 } else if (s.equals("examine")) {
   			 System.out.println("What do you wish to examine?(laptop,papers)");
   			 String m = scan.next().toLowerCase();
   			 if (m.equals("laptop")) {
   				 System.out
   						 .print("\nYou examine the laptop. It's on the lock screen with the professors "
   						 		+ "name in the corner. "
   								 + "\nThe laptop is asking for a password.(leave or enter password)\n>");
   				 Audio coww3 = new Audio("YouExamineTheLaptop.wav");
   				 s = scan.next().toLowerCase();
   				 if (s.equals("nicetrydummy")) {
   					 System.out.println(
   							 "\nThe professor has left a note saying \"I need to do my paper "
   							 + "on the Martian "
   									 + "\n industrial revolution so I will be at "
   									 + "the library looking through everybook if you need to find me\"");
   					 Audio coww4 = new Audio("TheProfessorHasLeftANote.wav");
   					 return -1;
   				 } else if (s.equals("leave")) {
   					 System.out.println("You leave the laptop alone.");
   				 } else {
   					 System.out.println("You can't come up with the right password and leave the laptop.");
   				 }
   			 } else if (m.equals("papers")) {
   				 System.out.println("The papers are a mad rambling of broken sentences and complex algorithms.");
   			 } else {
   				 System.out.println("You can't examine that");
   			 }
   		 } else if (s.equals("exit")) {

   			 return 1;
   		 }
   	 }
    }

    public int MemorialUnion5(Tracking i)// bookstore(This is where passcode for
   										 // laptop
    // is.)

    {
   	 
   	 System.out.println(
   			 "You enter the bookstore. The staple of iowa state Capitalism. There are three briefcases on the counter.");
   	 while (true) {
   		 System.out.println("What Do you want to do?:(search, examine,exit)");
   		 String s = scan.next().toLowerCase();

   		 if (s.equals("search")) {
   			 System.out.println("What do you want to search?(suitcase1,suitcase2,suitcase3)");
   			 String m = scan.next().toLowerCase();
   			 if (m.equals("suitcase1")) {
   				 System.out.println(
   						 "You search the first suitcase. Within it you find a piece of paper with the word(Nice) on it");
   			 } else if (m.equals("suitcase2")) {
   				 System.out.println(
   						 "You search the second suitcase. Within it you find a piece of paper with the word(Try) on it");

   			 } else if (m.equals("suitcase3")) {
   				 System.out.println(
   						 "You search the third suitcase. Within it you find a piece of paper with the word(Dummy) on it");

   			 }

   			 else {
   				 System.out.println("What are you even doing?");
   			 }
   		 } else if (s.equals("examine")) {
   			 System.out.println("What do you want to examine?:(suitcase1,suitcase2,suitcase3)");
   			 String k = scan.next().toLowerCase();
   			 if (k.equals("suitcase1")) {
   				 System.out.println("It's a black suitcase");
   			 } else if (k.equals("suitcase2")) {
   				 System.out.println("It's a black suitcase");
   			 } else if (k.equals("suitcase3")) {
   				 System.out.println("It's a black suitcase");
   			 }
   		 } else if (s.equals("exit")) {

   			 return 1;
   		 }
   	 }
    }

}


